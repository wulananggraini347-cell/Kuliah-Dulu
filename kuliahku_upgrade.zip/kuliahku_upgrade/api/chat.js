export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'Server belum dikonfigurasi dengan OPENAI_API_KEY.' });
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-8) : [];
  if (!message || message.length > 2000) return res.status(400).json({ error: 'Pesan kosong atau terlalu panjang.' });
  const safeHistory = history.filter(m => ['user', 'assistant'].includes(m?.role) && typeof m?.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 3000) }));
  try {
    const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'Kamu adalah asisten belajar untuk mahasiswa Indonesia. Jawab dalam bahasa Indonesia yang jelas, suportif, dan terstruktur. Bantu menjelaskan materi, membuat rencana belajar, dan memberi umpan balik; jangan mengerjakan kecurangan akademik atau mengarang sumber. Jika informasi kurang, tanyakan klarifikasi. Jangan meminta kata sandi atau data sensitif.' },
          ...safeHistory,
          { role: 'user', content: message }
        ],
        max_tokens: 700
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: 'Penyedia AI gagal memproses permintaan.' });
    const reply = data.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: 'Jawaban AI kosong.' });
    return res.status(200).json({ reply });
  } catch (e) {
    return res.status(500).json({ error: 'Terjadi masalah pada backend AI.' });
  }
}
