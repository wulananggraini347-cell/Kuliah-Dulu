# Kuliahku Upgrade — ungu pastel

## Fitur
- Jadwal kuliah dalam tabel yang bisa digeser di layar HP; tambah/edit/hapus.
- Evaluasi IPS perkiraan berbobot SKS berdasarkan nilai huruf.
- Portal tugas, deadline, prioritas, dan status selesai.
- Catatan kuliah lokal dan kalender ujian.
- Antarmuka chatbot AI yang memanggil endpoint `/api/chat`.
- Ekspor data JSON.

## Penting sebelum dipakai
`index.html` adalah frontend statis. Data jadwal, nilai, tugas, ujian, dan catatan tersimpan di browser/perangkat masing-masing (`localStorage`), bukan database bersama. Ekspor JSON secara berkala sebagai cadangan. Chatbot membutuhkan backend Vercel dan API key; GitHub Pages sendiri tidak menjalankan fungsi server.

## Mengganti index.html di GitHub (pemula)
1. Unduh dan ekstrak ZIP.
2. Buka repository `Kuliah-Dulu` di GitHub.
3. Buka `index.html`, klik ikon pensil Edit.
4. Di area editor, tekan `Ctrl+A`, lalu tempel seluruh isi file `index.html` yang ada di folder hasil ekstrak. Pastikan baris pertama `<!doctype html>` dan baris terakhir `</body></html>`.
5. Klik **Commit changes**. Tunggu deployment GitHub Pages selesai, lalu buka `https://wulananggraini347-cell.github.io/Kuliah-Dulu/` dan refresh keras (`Ctrl+Shift+R`).

## Mengaktifkan chatbot AI dengan aman
Agar `/api/chat` berfungsi, frontend dan API sebaiknya disajikan dari domain yang sama. GitHub Pages hanya hosting statis dan tidak dapat menjalankan `api/chat.js`. Cara paling mudah untuk pemula adalah deploy proyek ini ke Vercel:
1. Buat akun Vercel dan hubungkan repository GitHub, atau unggah folder proyek ini sebagai proyek baru.
2. Pastikan `index.html`, `api/chat.js`, dan `vercel.json` berada di root proyek/folder `api` seperti pada ZIP.
3. Di Vercel, buka **Project → Settings → Environment Variables**.
4. Tambahkan `OPENAI_API_KEY` dengan nilai API key milikmu. Jangan menulis key di `index.html`, GitHub, atau chat publik. Opsional: tambah `OPENAI_MODEL` dengan nama model yang tersedia di akun API-mu.
5. Deploy ulang setelah menambahkan environment variable.
6. Buka URL Vercel. Tes tab Tanya AI. Frontend GitHub Pages yang terpisah tidak akan memanggil backend Vercel pada kode default karena menggunakan URL relatif `/api/chat`; gunakan website yang di-host Vercel untuk versi chatbot terintegrasi.

## Keamanan dan biaya
- API key disimpan sebagai environment variable backend, bukan di browser.
- Jangan commit file `.env` atau menampilkan API key dalam screenshot.
- Panggilan API bisa menimbulkan biaya. Tetapkan budget/limit pada penyedia API, dan jangan bagikan URL backend secara publik sebelum menambahkan autentikasi, rate limiting, dan perlindungan penyalahgunaan.
- Contoh backend ini minimal. Untuk kelas sungguhan, tambahkan autentikasi pengguna, pembatasan jumlah permintaan, validasi input, dan pemantauan biaya.
- Jangan kirim nilai pribadi atau data sensitif ke chatbot.

## Data bersama antar mahasiswa
Untuk jadwal/tugas/nilai yang terlihat sama oleh satu kelas, dibutuhkan database backend (mis. Supabase) dan login sungguhan. Versi ini belum menyinkronkan data antarperangkat. Nilai dan IPS hanya untuk catatan pribadi dan tidak menggantikan sistem akademik resmi.
