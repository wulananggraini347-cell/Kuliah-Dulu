KULIAHKU — NAVY EDITION (PROTOTIPE AWAL)

Isi:
- index.html: website yang dapat dibuka di browser atau di-host.
- Fitur: tampilan jadwal mingguan, tugas/deadline, ujian, catatan, login demo, admin demo, impor/ekspor JSON.
- Login demo admin: pilih peran "Admin kelas (demo)" dan kode KULIAHKU26.

PENTING:
Ini adalah prototipe frontend. Data disimpan di localStorage browser, jadi perubahan tidak otomatis tersinkron ke HP mahasiswa lain. Login demo bukan autentikasi aman dan jangan digunakan untuk data rahasia. Untuk pemakaian satu kelas secara nyata, hubungkan ke backend seperti Supabase/Firebase dengan login sungguhan dan aturan akses admin.

Untuk hosting statis gratis:
1. Buka https://app.netlify.com/drop
2. Unggah folder yang berisi index.html (atau ZIP folder ini).
3. Setelah deploy, salin link *.netlify.app yang diberikan.
Alternatif: Cloudflare Pages Direct Upload: https://pages.cloudflare.com/
Jangan unggah data pribadi/rahasia ke prototipe ini.
